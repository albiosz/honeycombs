package com.albiosz.honeycombs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HoneycombsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HoneycombsApplication.class, args);
	}

}
