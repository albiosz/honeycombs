package com.albiosz.honeycombs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoneycombsApplicationTests {

	@Test
	void contextLoads() {
	}

}
